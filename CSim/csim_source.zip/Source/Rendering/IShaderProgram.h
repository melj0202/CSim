#pragma once 
#include <string>

struct ShaderPaths {
    std::string vertexPath;
    std::string fragmentPath;
    // Expandable later for geometry/compute paths
};

struct ShaderSources {
    std::string vertexSource;
    std::string fragmentSource;
    // Expandable later for geometry/compute paths
};

class IShaderProgram {
    public:
    IShaderProgram() = default;
    IShaderProgram(const ShaderPaths& paths){};
    IShaderProgram(const ShaderSources& sources){};
    virtual ~IShaderProgram() = default;
    virtual void CompileAndLink(const std::string& vertexSource, const std::string& fragmentSource) = 0;
    virtual void CompileAndLink(const ShaderSources& sources) = 0;
    virtual void CompileAndLink(const ShaderPaths& paths) = 0;
    virtual void Destroy() = 0;
    virtual unsigned long GetID() const = 0;

    protected:
    unsigned int _programID;
    unsigned int _vertexShadeID;
    unsigned int _fragmentShaderID;
};